package com.fisglobal.kgs.disclosure.entity.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "notification")
public class notification {
	
	@Id
	@DateTimeFormat(iso = ISO.DATE_TIME)
	@JsonFormat(pattern = "dd-MM-yy")
	private LocalDateTime datum;
	
	@Lob
	private String message;

	public LocalDateTime getDatum() {
		return datum;
	}

	public void setDatum(LocalDateTime datum) {
		this.datum = datum;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
