package com.fisglobal.kgs.disclosure.entity.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "questions")
public class questions {
	@Id
	@JsonProperty(value = "id")
	private int id;
	
	@JsonProperty(value = "name")
	@Lob
	private String name;
	
	@Transient
	@JsonProperty(value = "questionTypeId")
	private int questionTypeId;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "questions")
	@JsonProperty(value = "options")
	private List<options> options;
	
	@OneToOne
	@JsonProperty(value = "questionType")
	@JoinColumn(name="questionTypeId", referencedColumnName="id", foreignKey=@ForeignKey(name = "FK_questions_questionType"))
	private questionType questionType;
	
	@ManyToOne
	@JoinColumn(name="quizResponseId", referencedColumnName="id", foreignKey=@ForeignKey(name = "FK_questions_quizResponse"))
	@JsonIgnore
	private quizResponse quizResponse;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<options> getOptions() {
		return options;
	}
	public void setOptions(List<options> options) {
		this.options = options;
	}
	public questionType getQuestionType() {
		questionType.setActive(true);
		questionType.setId(this.questionTypeId);
		questionType.setName("");
		return questionType;
	}
	public void setQuestionType(questionType questionType) {
		questionType.setActive(true);
		questionType.setId(this.questionTypeId);
		questionType.setName("");
		this.questionType = questionType;
	}
	public quizResponse getQuizResponse() {
		return quizResponse;
	}
	public void setQuizResponse(quizResponse quizResponse) {
		this.quizResponse = quizResponse;
	}
	public int getQuestionTypeId() {
		questionTypeId=this.questionType.getId();
		return questionTypeId;
	}
	public void setQuestionTypeId(int questionTypeId) {
		this.questionTypeId = questionTypeId=this.questionType.getId();
	}
	
}
