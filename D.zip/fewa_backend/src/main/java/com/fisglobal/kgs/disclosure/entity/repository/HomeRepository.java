package com.fisglobal.kgs.disclosure.entity.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.fisglobal.kgs.disclosure.entity.model.home;

public interface HomeRepository extends CrudRepository<home, String>{
	
	home findByDatumAndMobileNumber(LocalDateTime datum, long mobileNumber);
	
	List<home> findAllByMobileNumber(long mobileNumber, Sort sort);
	
	@Query(value = "SELECT sum(score) from home where mobile_number = ?1", nativeQuery = true)
    int getTotalScore(long mobileNumber);

}
