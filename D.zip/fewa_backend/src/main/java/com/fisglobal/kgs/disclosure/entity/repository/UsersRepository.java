package com.fisglobal.kgs.disclosure.entity.repository;

import org.springframework.data.repository.CrudRepository;

import com.fisglobal.kgs.disclosure.entity.model.users;

public interface UsersRepository extends CrudRepository<users, String> {
	
	int countByMobileNumber(long mobileNumber);
	int countByMobileNumberAndPin(long mobileNumber, int pin);
	users getUserByMobileNumberAndPin(long mobileNumber, int pin);
	users getUserByMobileNumberAndSecurityQuestionAndSecurityAnswer(long mobileNumber, int securityQuestion, String securityAnswer);

}
