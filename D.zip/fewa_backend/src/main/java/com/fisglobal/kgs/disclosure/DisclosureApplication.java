package com.fisglobal.kgs.disclosure;

import java.io.FileNotFoundException;
import java.util.TimeZone;

import javax.xml.bind.JAXBException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class DisclosureApplication extends org.springframework.boot.web.servlet.support.SpringBootServletInitializer {
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(DisclosureApplication.class);
	}
	
	public static void main(String[] args) throws JAXBException, FileNotFoundException, Exception {
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		SpringApplication.run(DisclosureApplication.class, args);
	}

}

