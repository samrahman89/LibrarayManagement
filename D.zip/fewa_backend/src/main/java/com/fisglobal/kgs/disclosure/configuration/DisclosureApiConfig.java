package com.fisglobal.kgs.disclosure.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

@Component
@ConfigurationProperties(prefix = "kgs.disclosure.rspndgintrmy")
@Validated
public class DisclosureApiConfig {

	/**
	 * Enable JSON logging, default {@code true}.<br>
	 * ATTENTION: the default value which will be used by logback is configured in "logback-spring.xml"-file additionally.
	 * The default value here is used for visualization only. If you change it, don't forget to change the other value as well.
	 */
	private boolean jsonLoggingEnabled = true;

	private String bic;
	private String nm;
	private String adradrtp;
	private String adrstrtnm;
	private String adrbldgnb;
	private String adrpstcd;
	private String adrtwnnm;
	private String adrctry;
	private String lei;
	private String ctctprsnnmprfx;
	private String ctctprsngvnnm;
	private String ctctprsnnm;
	private String ctctprsnphnenb;
	private String ctctprsnemailadr;
			
	public boolean isJsonLoggingEnabled() {
		return jsonLoggingEnabled;
	}

	public void setJsonLoggingEnabled(boolean jsonLoggingEnabled) {
		this.jsonLoggingEnabled = jsonLoggingEnabled;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getNm() {
		return nm;
	}

	public void setNm(String nm) {
		this.nm = nm;
	}

	public String getAdradrtp() {
		return adradrtp;
	}

	public void setAdradrtp(String adradrtp) {
		this.adradrtp = adradrtp;
	}

	public String getAdrstrtnm() {
		return adrstrtnm;
	}

	public void setAdrstrtnm(String adrstrtnm) {
		this.adrstrtnm = adrstrtnm;
	}

	public String getAdrbldgnb() {
		return adrbldgnb;
	}

	public void setAdrbldgnb(String adrbldgnb) {
		this.adrbldgnb = adrbldgnb;
	}

	public String getAdrpstcd() {
		return adrpstcd;
	}

	public void setAdrpstcd(String adrpstcd) {
		this.adrpstcd = adrpstcd;
	}

	public String getAdrtwnnm() {
		return adrtwnnm;
	}

	public void setAdrtwnnm(String adrtwnnm) {
		this.adrtwnnm = adrtwnnm;
	}

	public String getAdrctry() {
		return adrctry;
	}

	public void setAdrctry(String adrctry) {
		this.adrctry = adrctry;
	}

	public String getLei() {
		return lei;
	}

	public void setLei(String lei) {
		this.lei = lei;
	}

	public String getCtctprsnnmprfx() {
		return ctctprsnnmprfx;
	}

	public void setCtctprsnnmprfx(String ctctprsnnmprfx) {
		this.ctctprsnnmprfx = ctctprsnnmprfx;
	}

	public String getCtctprsngvnnm() {
		return ctctprsngvnnm;
	}

	public void setCtctprsngvnnm(String ctctprsngvnnm) {
		this.ctctprsngvnnm = ctctprsngvnnm;
	}

	public String getCtctprsnnm() {
		return ctctprsnnm;
	}

	public void setCtctprsnnm(String ctctprsnnm) {
		this.ctctprsnnm = ctctprsnnm;
	}

	public String getCtctprsnphnenb() {
		return ctctprsnphnenb;
	}

	public void setCtctprsnphnenb(String ctctprsnphnenb) {
		this.ctctprsnphnenb = ctctprsnphnenb;
	}

	public String getCtctprsnemailadr() {
		return ctctprsnemailadr;
	}

	public void setCtctprsnemailadr(String ctctprsnemailadr) {
		this.ctctprsnemailadr = ctctprsnemailadr;
	}
	
}