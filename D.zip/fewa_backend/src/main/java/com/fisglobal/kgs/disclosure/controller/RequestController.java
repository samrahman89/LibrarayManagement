package com.fisglobal.kgs.disclosure.controller;

import com.fisglobal.kgs.disclosure.entity.model.home;
import com.fisglobal.kgs.disclosure.entity.model.homeDetails;
import com.fisglobal.kgs.disclosure.entity.model.notification;
import com.fisglobal.kgs.disclosure.entity.model.quizResponse;
import com.fisglobal.kgs.disclosure.entity.model.userObject;
import com.fisglobal.kgs.disclosure.entity.model.users;
import com.fisglobal.kgs.disclosure.entity.repository.HomeRepository;
import com.fisglobal.kgs.disclosure.entity.repository.NotificationRepository;
import com.fisglobal.kgs.disclosure.entity.repository.QuestionsRepository;
import com.fisglobal.kgs.disclosure.entity.repository.UsersRepository;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

@RestController
@Tag(name = "DisclosureRequests", description = "Query disclosure requests")
@Validated
public class RequestController {

	@Autowired
	private UsersRepository usersRespository;

	@Autowired
	private QuestionsRepository questionsRespository;

	@Autowired
	private HomeRepository homeRespository;

	@Autowired
	private NotificationRepository notificationRespository;

	@GetMapping(path = "/quiz", produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody quizResponse getQuizById(@RequestHeader(name = "mobile", required = true) final String mobile,
			@RequestHeader(name = "pin", required = true) final String pin, HttpServletResponse response)
			throws Exception {
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		int count = usersRespository.countByMobileNumberAndPin(Long.parseLong(mobile), Integer.parseInt(pin));
		if (count == 0) {
			response.sendError(400, "Invalid Credentials !!!");
			return null;
		} else {
			response.setStatus(200);
			DateFormat df = new SimpleDateFormat("yyyyMMdd");
			Date dObj = new Date();
			int datum = Integer.parseInt(df.format(dObj));
			LocalDateTime dateobj = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS);
			LocalDateTime sagarTime = dateobj.plus(4, ChronoUnit.HOURS);
			sagarTime = sagarTime.plus(30, ChronoUnit.MINUTES);

			if (sagarTime.compareTo(LocalDateTime.now()) > 0) {
				dateobj = dateobj.minus(1, ChronoUnit.DAYS);
				datum = datum - 1;
			}

			home home = new home();
			quizResponse quizResponse = questionsRespository.findById(datum);
			LocalDateTime dato = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS);
			LocalDateTime iftarTime = dato.plus(20, ChronoUnit.HOURS);
			iftarTime = iftarTime.plus(30, ChronoUnit.MINUTES);
			if (iftarTime.compareTo(LocalDateTime.now()) < 0 || sagarTime.compareTo(LocalDateTime.now()) > 0) {
				quizResponse.setAnswered(true);
			} else {
				if (null == homeRespository.findByDatumAndMobileNumber(dateobj, Long.parseLong(mobile))) {
					home.setDatum(dateobj);
					home.setStartTime(LocalDateTime.now());
					home.setMobileNumber(Long.parseLong(mobile));
					homeRespository.save(home);
				} else {
					home = homeRespository.findByDatumAndMobileNumber(dateobj, Long.parseLong(mobile));
				}
			}
			if (null != home.getEndTime())
				quizResponse.setAnswered(true);
			return quizResponse;
		}
	}

	@GetMapping(path = "/prevquiz", produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody quizResponse getPrevQuizById(
			@RequestHeader(name = "mobile", required = true) final String mobile,
			@RequestHeader(name = "pin", required = true) final String pin, HttpServletResponse response)
			throws Exception {
		int count = usersRespository.countByMobileNumberAndPin(Long.parseLong(mobile), Integer.parseInt(pin));
		if (count == 0) {
			response.sendError(400, "Invalid Credentials !!!");
			return null;
		} else {
			response.setStatus(200);
			DateFormat df = new SimpleDateFormat("yyyyMMdd");
			Date dateobj = new Date();
			int datum = Integer.parseInt(df.format(dateobj)) - 1;
			quizResponse quizResponse = questionsRespository.findById(datum);
			return quizResponse;
		}
	}

	@GetMapping(path = "/home", produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody homeDetails getHomeDetails(
			@RequestHeader(name = "mobile", required = true) final String mobile,
			@RequestHeader(name = "pin", required = true) final String pin, HttpServletResponse response)
			throws Exception {
		int count = usersRespository.countByMobileNumberAndPin(Long.parseLong(mobile), Integer.parseInt(pin));
		if (count == 0) {
			response.sendError(400, "Invalid Credentials !!!");
			return null;
		} else {
			response.setStatus(200);
			LocalDateTime dateobj = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS);
			homeDetails homeDetails = new homeDetails();
			home home = new home();
			if (null != homeRespository.findAllByMobileNumber(Long.parseLong(mobile),
					Sort.by(Sort.Direction.DESC, "datum")))
				homeDetails.setDetails(homeRespository.findAllByMobileNumber(Long.parseLong(mobile),
						Sort.by(Sort.Direction.DESC, "datum")));
			if (null != homeRespository.findByDatumAndMobileNumber(dateobj, Long.parseLong(mobile))) {
				home = homeRespository.findByDatumAndMobileNumber(dateobj, Long.parseLong(mobile));
				int score = homeRespository.getTotalScore(Long.parseLong(mobile));
				home.setTotalScore(score);
			}
			homeDetails.setHome(home);
			return homeDetails;
		}
	}

	@PostMapping(path = "/register", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public users registerUser(@Valid @RequestBody userObject userObject, HttpServletResponse response)
			throws ResponseStatusException, Throwable {
		users user = userObject.getOrder();

		if (user == null) {
			response.sendError(400, "Invalid Request !!!");
			return null;
		} else {
			int count = usersRespository.countByMobileNumber(user.getMobileNumber());
			if (count != 0) {
				response.sendError(400, "User Already Exists !!!");
				return null;
			} else {
				usersRespository.save(user);
				response.setStatus(200);
			}
		}

		return user;
	}

	@PostMapping(path = "/login", produces = MediaType.APPLICATION_JSON_VALUE)
	public users validateUser(@RequestHeader(name = "mobile", required = true) final String mobile,
			@RequestHeader(name = "pin", required = true) final String pin, HttpServletResponse response)
			throws ResponseStatusException, Throwable {

		int count = usersRespository.countByMobileNumberAndPin(Long.parseLong(mobile), Integer.parseInt(pin));
		if (count == 0) {
			response.sendError(400, "Invalid Credentials !!!");
			return null;
		} else {
			response.setStatus(200);
			return usersRespository.getUserByMobileNumberAndPin(Long.parseLong(mobile), Integer.parseInt(pin));
		}

	}

	@PostMapping(path = "/submit", produces = MediaType.APPLICATION_JSON_VALUE)
	public home registerUser(@Valid @RequestHeader(name = "mobile", required = true) final String mobile,
			@RequestHeader(name = "pin", required = true) final String pin,
			@RequestHeader(name = "score", required = true) final String score,
			@RequestHeader(name = "answers", required = true) final String answers, HttpServletResponse response)
			throws ResponseStatusException, Throwable {
		home home = new home();
		int count = usersRespository.countByMobileNumberAndPin(Long.parseLong(mobile), Integer.parseInt(pin));
		if (count == 0) {
			response.sendError(400, "Invalid Credentials !!!");
			return null;
		} else {
			LocalDateTime dateobj = LocalDateTime.now().truncatedTo(ChronoUnit.DAYS);
			LocalDateTime sagarTime = dateobj.plus(4, ChronoUnit.HOURS);
			sagarTime = sagarTime.plus(30, ChronoUnit.MINUTES);
			LocalDateTime iftarTime = dateobj.plus(20, ChronoUnit.HOURS);
			iftarTime = iftarTime.plus(30, ChronoUnit.MINUTES);
			if (iftarTime.compareTo(LocalDateTime.now()) < 0 || sagarTime.compareTo(LocalDateTime.now()) > 0) {
				response.sendError(400, "Time Window Closed !!!");
				return null;
			}
			if (null != homeRespository.findByDatumAndMobileNumber(dateobj, Long.parseLong(mobile))) {
				home = homeRespository.findByDatumAndMobileNumber(dateobj, Long.parseLong(mobile));
				if (home.getEndTime() == null) {
					users user = usersRespository.getUserByMobileNumberAndPin(Long.parseLong(mobile), Integer.parseInt(pin));
					String country = user.getCountry();
					if(country.equals("India")) home.setEndTimeISO(LocalDateTime.now().plus(330,ChronoUnit.MINUTES));
					if(country.equals("UAE")) home.setEndTimeISO(LocalDateTime.now().plus(240,ChronoUnit.MINUTES));
					if(country.equals("Kuwait")) home.setEndTimeISO(LocalDateTime.now().plus(180,ChronoUnit.MINUTES));
					if(country.equals("KSA")) home.setEndTimeISO(LocalDateTime.now().plus(180,ChronoUnit.MINUTES));
					if(country.equals("Qatar")) home.setEndTimeISO(LocalDateTime.now().plus(180,ChronoUnit.MINUTES));
					if(country.equals("Oman")) home.setEndTimeISO(LocalDateTime.now().plus(240,ChronoUnit.MINUTES));
					if(country.equals("Bahrain")) home.setEndTimeISO(LocalDateTime.now().plus(240,ChronoUnit.MINUTES));
					if(country.equals("Brunei")) home.setEndTimeISO(LocalDateTime.now().plus(480,ChronoUnit.MINUTES));
					if(country.equals("Maldives")) home.setEndTimeISO(LocalDateTime.now().plus(300,ChronoUnit.MINUTES));
					if(country.equals("Malaysia")) home.setEndTimeISO(LocalDateTime.now().plus(480,ChronoUnit.MINUTES));
					if(country.equals("Singapore")) home.setEndTimeISO(LocalDateTime.now().plus(480,ChronoUnit.MINUTES));
					if(country.equals("SriLanka")) home.setEndTimeISO(LocalDateTime.now().plus(330,ChronoUnit.MINUTES));
					if(country.equals("France")) home.setEndTimeISO(LocalDateTime.now().plus(120,ChronoUnit.MINUTES));
					if(country.equals("Australia")) home.setEndTimeISO(LocalDateTime.now().plus(600,ChronoUnit.MINUTES));
					if(country.equals("Canada")) home.setEndTimeISO(LocalDateTime.now().minus(240,ChronoUnit.MINUTES));
					home.setScore(Integer.parseInt(score));
					home.setEndTime(LocalDateTime.now());
					home.setAnswers(answers);
					homeRespository.save(home);
				} else {
					response.sendError(400, "Answers submitted already !!!");
					return null;
				}
			}
			response.setStatus(200);
		}
		return home;
	}

	@PostMapping(path = "/forgotpin", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public users returnPin(@Valid @RequestBody userObject userObject, HttpServletResponse response)
			throws ResponseStatusException, Throwable {
		users user = userObject.getOrder();

		if (user == null) {
			response.sendError(400, "Invalid Request !!!");
			return null;
		} else {

			users userDB = usersRespository.getUserByMobileNumberAndSecurityQuestionAndSecurityAnswer(
					user.getMobileNumber(), user.getSecurityQuestion(), user.getSecurityAnswer());
			if (userDB != null) {
				return userDB;
			} else {
				response.sendError(400, "Invalid Request !!!");
				return null;
			}
		}
	}

	@GetMapping(path = "/notification", produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody List<notification> getNotify(
			@RequestHeader(name = "mobile", required = true) final String mobile,
			@RequestHeader(name = "pin", required = true) final String pin, HttpServletResponse response)
			throws Exception {
		int count = usersRespository.countByMobileNumberAndPin(Long.parseLong(mobile), Integer.parseInt(pin));
		if (count == 0) {
			response.sendError(400, "Invalid Credentials !!!");
			return null;
		} else {
			response.setStatus(200);
			return notificationRespository.findAll(Sort.by(Sort.Direction.DESC, "datum"));
		}

	}
}
