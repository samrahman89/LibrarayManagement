package com.fisglobal.kgs.disclosure.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import static org.springframework.http.HttpMethod.POST;

/**
 * author e3016939, Madhavan Jayaraman
 * date 3/28/2020 , time 10:14 PM
 * project_name srd_backend
 * package_name com.fisglobal.kgs.disclosure.configuration\
 **/
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter implements WebMvcConfigurer {
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                //.httpBasic()
                //.and()
                .authorizeRequests()
                .antMatchers(HttpMethod.OPTIONS,"/**").permitAll()
                .antMatchers(POST, "/quiz/**").permitAll() // not protected REST-API as either basic auth or parameter values of user/password are allowed
                .antMatchers(HttpMethod.GET, "/quiz/**").permitAll() // not protected REST-API
                .antMatchers(POST, "/", "favicon.ico", "/csrf", "/swagger-ui/**", "/swagger-resources/**", "/webjars/**", "/v2/api-docs").permitAll() // allow Swagger-UI
                .antMatchers(POST, "/actuator/health", "/actuator/info").permitAll() // allow actuator endpoints
                .anyRequest().permitAll();
                 //.formLogin().and()
                //.httpBasic();
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedHeaders("*")
                        .allowedMethods("*")
                .allowCredentials(true)
                .maxAge(3600);
            }
        };
    }
}
