package com.fisglobal.kgs.disclosure.entity.model;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "options")
public class options {
	@Id
	@JsonProperty(value = "id")
	private int id;
	
	@JsonProperty(value = "name")
	private String name;
	
	@JsonProperty(value = "isAnswer")
	private boolean isAnswer;
	
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="questionId", referencedColumnName="id", foreignKey=@ForeignKey(name = "FK_options_questions"))
	private questions questions;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isAnswer() {
		return isAnswer;
	}
	public void setAnswer(boolean isAnswer) {
		this.isAnswer = isAnswer;
	}
	public questions getQuestions() {
		return questions;
	}
	public void setQuestions(questions questions) {
		this.questions = questions;
	}

}
