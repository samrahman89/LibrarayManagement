package com.fisglobal.kgs.disclosure.entity.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class userObject {
	
	@JsonProperty("user")
	public users userObject;

    public userObject() {}

	public userObject(users userObject) {
		super();
		this.userObject = userObject;
	}

	public users getOrder() {
		return userObject;
	}

	public void setOrder(users userObject) {
		this.userObject = userObject;
	}

}
