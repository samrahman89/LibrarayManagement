package com.fisglobal.kgs.disclosure.entity.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "quizResponse")

public class quizResponse {
	
	@Id
	@JsonProperty(value = "id")
	private int id;
	
	@JsonProperty(value = "name")
	private String name;
	
	@JsonProperty(value = "description")
	private String description;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "quizResponse")
	@JsonProperty(value = "questions")
	private List<questions> questions;
	
	@Transient
	private Boolean answered;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<questions> getQuestions() {
		return questions;
	}
	public void setQuestions(List<questions> questions) {
		this.questions = questions;
	}
	public Boolean getAnswered() {
		return answered;
	}
	public void setAnswered(Boolean answered) {
		this.answered = answered;
	}

}
