package com.fisglobal.kgs.disclosure.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

/**
 * author e3016939, Madhavan Jayaraman
 * date 3/27/2020 , time 1:55 PM
 * project_name srd_backend
 * package_name com.fisglobal.kgs.disclosure.configuration\
 **/
@Component
@Validated
@ConfigurationProperties(prefix = "kgs.disclosure.schema")
public class SchemaFileConfig {
    private String xsdPath;
    private String businessHeader;
    private String disclosureRequest;

    public String getXsdPath() {
        return xsdPath;
    }

    public void setXsdPath(String xsdPath) {
        this.xsdPath = xsdPath;
    }

    public String getBusinessHeader() {
        return businessHeader;
    }

    public void setBusinessHeader(String businessHeader) {
        this.businessHeader = businessHeader;
    }

    public String getDisclosureRequest() {
        return disclosureRequest;
    }

    public void setDisclosureRequest(String disclosureRequest) {
        this.disclosureRequest = disclosureRequest;
    }
}
