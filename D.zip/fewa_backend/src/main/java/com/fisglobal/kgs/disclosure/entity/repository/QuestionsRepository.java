package com.fisglobal.kgs.disclosure.entity.repository;

import org.springframework.data.repository.CrudRepository;

import com.fisglobal.kgs.disclosure.entity.model.quizResponse;

public interface QuestionsRepository extends CrudRepository<quizResponse, String> {
	quizResponse findById(int id);

}
