package com.fisglobal.kgs.disclosure.entity.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.repository.CrudRepository;

import com.fisglobal.kgs.disclosure.entity.model.notification;

public interface NotificationRepository extends CrudRepository<notification, String>{
	
	List<notification> findAll(Sort sort);

}
