package com.fisglobal.kgs.disclosure.entity.model;

import java.util.List;

public class homeDetails {
	
	private home home;
	
	private List<home> details;

	public home getHome() {
		return home;
	}

	public void setHome(home home) {
		this.home = home;
	}

	public List<home> getDetails() {
		return details;
	}

	public void setDetails(List<home> details) {
		this.details = details;
	} 

}
