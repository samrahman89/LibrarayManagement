package com.fisglobal.kgs.disclosure.configuration;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.oas.models.servers.ServerVariable;
import io.swagger.v3.oas.models.servers.ServerVariables;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
@Configuration
public class OpenApiConfig {
	
	@Bean
    public OpenAPI api() {
		return new OpenAPI()
            .info(new Info()
            		.title("kgs-api_disclosure")
            		.description("APIs for SRDII disclosure processing")
            		.contact(new Contact().email("DE_Wertpapier@fisglobal.com"))
            		.version("v1")
            		.license(new License().name("FIS COPYRIGHT (C) 2019 Fidelity National Information Services, Inc. and/or\r\n" + 
    				"      its subsidiaries - All Rights Reserved worldwide. This document is\r\n" + 
    				"      protected under the trade secret and copyright laws as the property of\r\n" + 
    				"      Fidelity National Information Services, Inc. and/or its subsidiaries.\r\n" + 
    				"      Copying, reproduction or distribution should be limited and only to\r\n" + 
    				"      employees with a ( need to know ) to do their job. Any disclosure of this\r\n" + 
    				"      document to third parties is strictly prohibited.")))
            .addServersItem(new Server().url("http://{environment}:{port}/api/kgs-api/disclosure/v1")
            		.variables(new ServerVariables()
            				.addServerVariable("port", new ServerVariable()._default("18081"))
            				.addServerVariable("environment", new ServerVariable()._default("localhost"))))
            .addServersItem(new Server().url("https://{environment}:{port}/api/kgs-api/disclosure/v1")
            		.variables(new ServerVariables()
            				.addServerVariable("port", new ServerVariable()._default("18081"))
            				.addServerVariable("environment", new ServerVariable()._default("localhost"))))
            .addSecurityItem(new SecurityRequirement().addList("basicAuth"))
			.components(new Components().addSecuritySchemes("basicAuth", new SecurityScheme()
		            .type(SecurityScheme.Type.HTTP)
		            .scheme("basic")));
	}
}