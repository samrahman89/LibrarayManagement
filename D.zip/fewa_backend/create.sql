
    create table home (
       id varchar(255) not null,
        datum datetime,
        endTime datetime,
        mobileNumber bigint not null,
        score integer not null,
        startTime datetime,
        primary key (id)
    ) engine=InnoDB;

    create table notification (
       datum datetime not null,
        message longtext,
        primary key (datum)
    ) engine=InnoDB;

    create table options (
       id integer not null,
        isAnswer bit not null,
        name varchar(255),
        questionId integer,
        primary key (id)
    ) engine=InnoDB;

    create table questions (
       id integer not null,
        name varchar(255),
        questionTypeId integer,
        quizResponseId integer,
        primary key (id)
    ) engine=InnoDB;

    create table questionType (
       id integer not null,
        isActive bit not null,
        name varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table quizResponse (
       id integer not null,
        description varchar(255),
        name varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table users (
       mobileNumber bigint not null,
        firstName varchar(255),
        pin integer not null,
        securityAnswer varchar(255),
        securityQuestion integer not null,
        primary key (mobileNumber)
    ) engine=InnoDB;

    alter table options 
       add constraint FK_options_questions 
       foreign key (questionId) 
       references questions (id);

    alter table questions 
       add constraint FK_questions_questionType 
       foreign key (questionTypeId) 
       references questionType (id);

    alter table questions 
       add constraint FK_questions_quizResponse 
       foreign key (quizResponseId) 
       references quizResponse (id);

    create table home (
       id varchar(255) not null,
        datum datetime,
        endTime datetime,
        mobileNumber bigint not null,
        score integer not null,
        startTime datetime,
        primary key (id)
    ) engine=InnoDB;

    create table notification (
       datum datetime not null,
        message longtext,
        primary key (datum)
    ) engine=InnoDB;

    create table options (
       id integer not null,
        isAnswer bit not null,
        name varchar(255),
        questionId integer,
        primary key (id)
    ) engine=InnoDB;

    create table questions (
       id integer not null,
        name varchar(255),
        questionTypeId integer,
        quizResponseId integer,
        primary key (id)
    ) engine=InnoDB;

    create table questionType (
       id integer not null,
        isActive bit not null,
        name varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table quizResponse (
       id integer not null,
        description varchar(255),
        name varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table users (
       mobileNumber bigint not null,
        firstName varchar(255),
        pin integer not null,
        securityAnswer varchar(255),
        securityQuestion integer not null,
        primary key (mobileNumber)
    ) engine=InnoDB;

    alter table options 
       add constraint FK_options_questions 
       foreign key (questionId) 
       references questions (id);

    alter table questions 
       add constraint FK_questions_questionType 
       foreign key (questionTypeId) 
       references questionType (id);

    alter table questions 
       add constraint FK_questions_quizResponse 
       foreign key (quizResponseId) 
       references quizResponse (id);

    create table home (
       id varchar(255) not null,
        datum datetime,
        endTime datetime,
        mobileNumber bigint not null,
        score integer not null,
        startTime datetime,
        primary key (id)
    ) engine=InnoDB;

    create table notification (
       datum datetime not null,
        message longtext,
        primary key (datum)
    ) engine=InnoDB;

    create table options (
       id integer not null,
        isAnswer bit not null,
        name varchar(255),
        questionId integer,
        primary key (id)
    ) engine=InnoDB;

    create table questions (
       id integer not null,
        name varchar(255),
        questionTypeId integer,
        quizResponseId integer,
        primary key (id)
    ) engine=InnoDB;

    create table questionType (
       id integer not null,
        isActive bit not null,
        name varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table quizResponse (
       id integer not null,
        description varchar(255),
        name varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table users (
       mobileNumber bigint not null,
        firstName varchar(255),
        pin integer not null,
        securityAnswer varchar(255),
        securityQuestion integer not null,
        primary key (mobileNumber)
    ) engine=InnoDB;

    alter table options 
       add constraint FK_options_questions 
       foreign key (questionId) 
       references questions (id);

    alter table questions 
       add constraint FK_questions_questionType 
       foreign key (questionTypeId) 
       references questionType (id);

    alter table questions 
       add constraint FK_questions_quizResponse 
       foreign key (quizResponseId) 
       references quizResponse (id);
