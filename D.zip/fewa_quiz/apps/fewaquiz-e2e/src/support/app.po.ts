export const getGreeting = () => cy.get('ruf-page-header-title');
