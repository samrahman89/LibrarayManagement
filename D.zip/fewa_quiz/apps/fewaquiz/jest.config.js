module.exports = {
  name: 'fewaquiz',
  preset: '../../jest.config.js',
  coverageDirectory: '../../coverage/apps/fewaquiz',
  snapshotSerializers: [
    'jest-preset-angular/AngularSnapshotSerializer.js',
    'jest-preset-angular/HTMLCommentSerializer.js'
  ]
};
