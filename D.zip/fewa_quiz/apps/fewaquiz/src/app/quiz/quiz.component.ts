import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Option, Question, Quiz, QuizConfig } from '../models/index';
import {
  MatSnackBar,
} from '@angular/material';
import { API_URL } from '../app.constants';

@Component({
  selector: 'fewaquiz-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  quizes: any[];
  quiz: Quiz = new Quiz(null);
  mode = 'quiz';
  quizName: string;
  config: QuizConfig = {
    'allowBack': true,
    'allowReview': false,
    'autoMove': false,  // if true, it will move to next question automatically when answered.
    'duration': 300,  // indicates the time (in secs) in which quiz needs to be completed. 0 means unlimited.
    'pageSize': 1,
    'requiredAll': true,  // indicates if you must answer all the questions before submitting.
    'richText': true,
    'shuffleQuestions': false,
    'shuffleOptions': false,
    'showClock': false,
    'showPager': true,
    'theme': 'none'
  };

  pager = {
    index: 0,
    size: 1,
    count: 1
  };
  isWait=true;
  postId: any;
  message = 'Please answer all the questions to submit.';
  isAllAnswered = false;

  constructor(private  http: HttpClient, public snackBar: MatSnackBar,
    private router: Router) { }

  ngOnInit() {
    this.loadQuiz('FEWA Quiz');
  }

  loadQuiz(quizName: string) {
    const mobile = localStorage.getItem("mobile");
    const pin = localStorage.getItem("pin");
    this.http.get(API_URL+'quiz', { headers: {"mobile": mobile,
    "pin":pin} }).subscribe(res => {
      this.quiz = new Quiz(res);
      this.isWait=false;
      if(this.quiz.questions!==undefined)
      {
      this.pager.count = this.quiz.questions.length;
      }
    },
    (err: HttpErrorResponse) => {
      this.isWait=false;
      let message="Server Error";
      if(err.error!==undefined)
      {
        message=err.error.message
      }
      this.snackBar.open(message, 'X',
      { duration: 10000, panelClass: ['blue-snackbar'],});
    }
    );
  }

  get filteredQuestions() {
    return (this.quiz.questions) ?
      this.quiz.questions.slice(this.pager.index, this.pager.index + this.pager.size) : [];
  }

  onSelect(question: Question, option: Option) {
    if (question.questionTypeId === 1) {
      this.isAllAnswered = true;
      question.options.forEach((x) => { if (x.id !== option.id) x.selected = false; });
      this.quiz.questions.forEach((x) => {x.answered=this.isAnswered(x);});
      this.quiz.questions.forEach((x) => { if (x.answered !== true) {this.isAllAnswered = false;} });
    }

    if (this.config.autoMove) {
      this.goTo(this.pager.index + 1);
    }
  }

  goTo(index: number) {
    if (index >= 0 && index < this.pager.count) {
      this.pager.index = index;
      this.mode = 'quiz';
    }
  }

  isAnswered(question: Question) {
    return question.options.find(x => x.selected) ? true : false;
  };

  isCorrect(question: Question) {
    return question.options.every(x => x.selected === x.isAnswer) ? true : false;
  };

  onSubmit() {
    this.isAllAnswered=true;
    if(this.quiz.questions===undefined)
    {return}
    this.quiz.questions.forEach((x) => {x.answered=this.isAnswered(x);});
    this.quiz.questions.forEach((x) => { if (x.answered !== true) {this.isAllAnswered = false;} })

    if(this.isAllAnswered !== true) {
      this.snackBar.open(this.message, null, {
        duration: 2000,
        panelClass: ['blue-snackbar']
      });
    }
    else
    {
      const mobile = localStorage.getItem("mobile");
      const pin = localStorage.getItem("pin");
      const s = this.getScore();
      const s1=s.toString();
      const a = this.getAnswers();
      const a1= a.toString();
      this.isWait=true;
      this.http.post<any>(API_URL+'submit/',{}, {headers: {"mobile": mobile,
      "pin":pin, "score": s1, "answers": a1}}).subscribe(data => {
        this.isWait=false;
            this.postId=data.id;
            this.quiz.answered=true;
            this.snackBar.open("You have submitted the answers successfully !!!", 'X',
            { duration: 10000, panelClass: ['snack-success'],});
            this.router.navigate(['/home'], { replaceUrl: true });
        },
        (err: HttpErrorResponse) => {
          this.isWait=false;
          this.snackBar.open(err.error.message, 'X',
          { duration: 10000, panelClass: ['blue-snackbar'],});
        }
        )
      }
    };
    goBack(){
      this.router.navigate(['/home'], { replaceUrl: true });
    }
    getScore(){
      let score=0;
      this.quiz.questions.forEach((question) => {
        if(this.isCorrect(question)){
          score = score +1;
        }
      })
      return score;
    };
    getAnswers(){
      const answers=[];
      this.quiz.questions.forEach((question) => {
        let index=0;
        question.options.forEach((options)=> {
          index++;
          if(options.selected===true){answers.push(index)}})
      })
      return answers.toString();
    };
}
