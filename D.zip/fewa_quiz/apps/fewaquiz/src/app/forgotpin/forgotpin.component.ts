import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {
  MatSnackBar,
  MatSnackBarConfig,
} from '@angular/material';

import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { API_URL } from '../app.constants';

export class RegisterDetails {
  constructor (
    public mobile: number,
    public pin: number,
    public repeatPin: number,
    public securityQuestionId: number,
    public securityQuestionAnswer: string,
    public firstName: string
  ) {

  }
}
@Component({
  selector: 'fewaquiz-forgotpin',
  templateUrl: './forgotpin.component.html',
  styleUrls: ['./forgotpin.component.scss']
})
export class ForgotpinComponent implements OnInit {

  constructor(private router: Router, public snackBar: MatSnackBar, private http: HttpClient) {

   }

   registerDetails : RegisterDetails
   isWait = false
  ngOnInit() {
    this.registerDetails=new RegisterDetails(null,null,null,null,null,null);
  }

  showPin() : void {
    if(this.registerDetails.mobile !== null && this.registerDetails.securityQuestionId !== null &&
      this.registerDetails.securityQuestionAnswer !== null ){
        this.isWait=true;
        this.http.post(`${API_URL}` +'forgotpin', {user: this.registerDetails }).subscribe((rD: RegisterDetails)=>{
        this.isWait=false;
        this.snackBar.open("Your PIN is " +rD.pin, 'X',
          { duration: 10000});
        },
        (err: HttpErrorResponse) => {
          this.isWait=false;
          let message="Server Error";
          if(err.error!==undefined)
          {
            message=err.error.message
          }
          this.snackBar.open(message, 'X',
          { duration: 10000, panelClass: ['blue-snackbar'],});
        }
        );
    }
    else {
      const config = new MatSnackBarConfig();
      const message = "Please fill all the details to recover PIN"
      this.snackBar.open(message, null, {
        duration: 2000,
        panelClass: ['blue-snackbar']
      });
      return;
    }
  }
}
