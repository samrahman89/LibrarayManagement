import { Component, OnInit } from '@angular/core';
import { Question, Quiz } from '../models/index';
import { Router } from '@angular/router';

@Component({
  selector: 'fewaquiz-submit',
  templateUrl: './submit.component.html',
  styleUrls: ['./submit.component.scss']
})
export class SubmitComponent implements OnInit {

  pager = {
    index: 0,
    size: 1,
    count: 1
  };

  quiz: Quiz = new Quiz(null);
  res: any;
  constructor(private router:Router) {
}
  ngOnInit() {
    this.res = history.state;
    this.quiz=this.res.id;
    if(this.quiz===undefined || this.quiz.questions===undefined)
    {
      this.quiz= new Quiz(null);
    }
  }

  get filteredQuestions() {
    return (this.quiz.questions) ?
      this.quiz.questions.slice(this.pager.index, this.pager.index + this.pager.size) : [];
  }

  goTo(index: number) {
    if (index >= 0 && index < this.pager.count) {
      this.pager.index = index;
    }
  }

  isAnswered(question: Question) {
    return question.options.find(x => x.selected) ? 'Answered' : 'Not Answered';
  };

  isCorrect(question: Question) {
    return question.options.every(x => x.selected === x.isAnswer) ? true : false;
  };

  isWrong(question: Question) {
    return question.options.every(x => x.selected === x.isAnswer) ? false : true;
  };

  returnAnswer(question: Question) {
    let name = "";
    question.options.forEach((x) => { if (x.isAnswer){name=x.name }});
    return name;
  };

  goBack(){
    this.router.navigate(['/home'], { replaceUrl: true });
  }

}
