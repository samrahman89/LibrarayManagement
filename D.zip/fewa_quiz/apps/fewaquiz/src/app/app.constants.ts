export const API_URL = "http://quizbee-env-1.eba-u8mahpym.us-east-2.elasticbeanstalk.com/fewa_backend/"
//export const API_URL = "http://localhost:8080/fewa_backend/"
