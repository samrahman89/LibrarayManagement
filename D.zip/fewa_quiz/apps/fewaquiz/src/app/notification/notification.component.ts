import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatSnackBar } from '@angular/material';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Notification} from '../models/notification';
import { API_URL } from '../app.constants';

@Component({
  selector: 'fewaquiz-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {
  displayedColumns: string[] = ['datum', 'message'];
  dataSource = new MatTableDataSource();
  name = localStorage.getItem("name");
  isWait=true;

  constructor(private http: HttpClient, public snackBar: MatSnackBar) { }

  ngOnInit() {
    const mobile = localStorage.getItem("mobile");
    const pin = localStorage.getItem("pin");
    this.http.get(API_URL+'notification', { headers: {"mobile": mobile,
    "pin":pin} }).subscribe((notifications: Notification[])=>{
      this.dataSource.data = notifications;
      this.isWait=false;
    },
    (err: HttpErrorResponse) => {
      this.isWait=false;
      let message="Server Error";
      if(err.error!==undefined)
      {
        message=err.error.message
      }
      this.snackBar.open(message, 'X',
      { duration: 10000, panelClass: ['blue-snackbar'],});
    }
    );
  }

  onRefresh(){
    const mobile = localStorage.getItem("mobile");
    const pin = localStorage.getItem("pin");
    this.isWait=true;
    this.http.get(API_URL+'notification', { headers: {"mobile": mobile,
    "pin":pin} }).subscribe((notifications: Notification[])=>{
      this.dataSource.data = notifications;
      this.isWait=false;
    },
    (err: HttpErrorResponse) => {
      let message="Server Error";
      this.isWait=true;
      if(err.error!==undefined)
      {
        message=err.error.message
      }
      this.snackBar.open(message, 'X',
      { duration: 10000, panelClass: ['blue-snackbar'],});
    }
    );
  }
}
