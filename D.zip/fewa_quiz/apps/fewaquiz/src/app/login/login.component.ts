import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material';
import { API_URL } from '../app.constants';

import { HttpClient, HttpErrorResponse } from '@angular/common/http';

export class LoginDetails {
  constructor (
    public mobile: string,
    public pin: string,
    public firstName: string
  ) {

  }
}

@Component({
  selector: 'fewaquiz-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  message = 'Invalid Credentials.';
  hide = true;
  action = true;
  setAutoHide = true;
  autoHide= 2000;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  isAllAnswered = true;
  postId: any;
  isWait=false;

  constructor(private router: Router, public snackBar: MatSnackBar, private http: HttpClient) { }
  loginDetails : LoginDetails
    ngOnInit() {
      this.loginDetails=new LoginDetails(localStorage.getItem("mobile"),localStorage.getItem("pin"), localStorage.getItem("name"));
    }
    handleLogin() : void {
  if(this.loginDetails.mobile !== null && this.loginDetails.pin !== null){
    this.isWait=true;
    this.http.post<any>(API_URL+'login/', {},{ headers: {"mobile": this.loginDetails.mobile,
  "pin":this.loginDetails.pin} }).subscribe((log : LoginDetails)=> {
    this.isWait=false;
      localStorage.setItem("mobile", log.mobile);
      localStorage.setItem("pin", log.pin);
      localStorage.setItem("name", log.firstName);
      this.router.navigate(["home"]);
  },
  (err: HttpErrorResponse) => {
    this.isWait=false;
    let message="Server Error";
    if(err.error!==undefined)
    {
      message=err.error.message
    }
    this.snackBar.open(message, 'X',
    { duration: 10000, panelClass: ['blue-snackbar'],});
  }
  )
  }else {
    this.snackBar.open(this.message, null, {
      duration: 2000,
      panelClass: ['blue-snackbar']
    });
  }
  }
}
