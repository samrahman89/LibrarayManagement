
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // Don't like animations? Replace this with NoopAnimationsModule
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';

import {
  RufAppCanvasModule,
  RufLayoutModule,
  RufBannerModule,
  RufFooterModule,
  RufIconModule,
  RufMenubarModule,
  RufNavbarModule,
  RufPageHeaderModule
} from '@ruf/shell';

import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LOCALE_ID} from '@angular/core';
import localeDe from '@angular/common/locales/de';
import localeDeExtra from '@angular/common/locales/extra/de';
import { registerLocaleData, DatePipe } from '@angular/common';

import { CommonModule } from '@angular/common';
import {
  MatIconModule,
  MatPaginatorModule,
  MatInputModule,
  MatFormFieldModule,
  MatCardModule,
  MatCheckboxModule,
  MatToolbarModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatSelectModule,
  MatTabsModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatTableModule,
  MatSnackBarModule,
  MatExpansionModule,
  MatSortModule,
  MatProgressSpinnerModule,
  MatDividerModule
 } from '@angular/material';

import {TranslateLoader, TranslateModule} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import { WelcomeComponent } from './welcome/welcome.component';
import { QuizComponent } from './quiz/quiz.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { AboutComponent } from './about/about.component';
import { SubmitComponent } from './submit/submit.component';
import { ForgotpinComponent } from './forgotpin/forgotpin.component';
import { PreviousquizComponent } from './previousquiz/previousquiz.component';
import { NotificationComponent } from './notification/notification.component';

registerLocaleData(localeDe, localeDeExtra);

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    QuizComponent,
    LoginComponent,
    HomeComponent,
    RegisterComponent,
    AboutComponent,
    SubmitComponent,
    ForgotpinComponent,
    PreviousquizComponent,
    NotificationComponent],

  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    FlexLayoutModule,
    MatIconModule,
    BrowserAnimationsModule,
    RufAppCanvasModule,
    RufBannerModule,
    RufFooterModule,
    RufIconModule,
    RufMenubarModule,
    RufNavbarModule,
    RufPageHeaderModule,
    ReactiveFormsModule,
    CommonModule,
    MatInputModule,
    MatCardModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatFormFieldModule,
    MatSelectModule,
    MatTabsModule,
    RufPageHeaderModule,
    RufIconModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTableModule,
    MatSnackBarModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    BrowserAnimationsModule,
    //RufNgxChartsModule,
    MatExpansionModule,
    MatSortModule,
    MatPaginatorModule ,
    TranslateModule.forRoot({
      loader: {
          provide: TranslateLoader,
          useFactory: HttpLoaderFactory,
          deps: [HttpClient]
      }
  })
  ],

  exports: [
    MatSortModule,
  ],

  entryComponents: [],
  providers: [
    //DisclosurerequestsSearchService,
    {provide: LOCALE_ID, useValue: 'de'} ,
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

// required for AOT compilation
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/');
}

