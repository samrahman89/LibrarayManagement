export class Home {
    id: string;
    mobileNumber: number;
    datum: string;
    startTime: string;
    endTime: string;
    score: number;
    totalScore: number;

    constructor(data: any) {
        if (data) {
            this.id = data.id;
            this.mobileNumber = data.mobileNumber;
            this.datum = data.datum;
            this.startTime = data.startTime;
            this.endTime = data.endTime;
            this.score = data.score;
            this.totalScore = data.totalScore;
        }
    }
}
