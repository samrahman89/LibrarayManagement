import { Home } from './home';

export class HomeDetails {
    home: Home;
    details: Home[];

    constructor(data: any) {
        if (data) {
            this.home = data.home;
            this.details = [];
            data.details.forEach(q => {
                this.details.push(new Home(q));
            });
        }
    }
}
