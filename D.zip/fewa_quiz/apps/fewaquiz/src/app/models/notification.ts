export class Notification {
  datum: string;
  message: string;

  constructor(data: any) {
      if (data) {
          this.datum = data.datum;
          this.message = data.message;
      }
  }
}
