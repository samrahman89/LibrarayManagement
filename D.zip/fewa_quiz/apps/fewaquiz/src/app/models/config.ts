export class Config {
  url: string;

  constructor(data: any) {
      data = data || {};
      this.url = data.url;
  }
}
