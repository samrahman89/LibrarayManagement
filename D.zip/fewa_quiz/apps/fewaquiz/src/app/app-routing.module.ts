import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import {QuizComponent} from './quiz/quiz.component';
import {SubmitComponent} from './submit/submit.component';
import {RegisterComponent} from './register/register.component';
import {AboutComponent} from './about/about.component';
import {ForgotpinComponent} from './forgotpin/forgotpin.component';
import {PreviousquizComponent} from './previousquiz/previousquiz.component';
import {NotificationComponent} from './notification/notification.component';

const routes: Routes = [
  { path: '', component: LoginComponent},
  {path: 'home', component:HomeComponent},
  {path: 'quiz', component:QuizComponent},
  {path: 'register', component:RegisterComponent},
  {path: 'submit', component:SubmitComponent},
  {path: 'about', component:AboutComponent},
  {path: 'fewa/apps/fewaquiz/about', component:AboutComponent},
  {path: 'forgotpin', component:ForgotpinComponent},
  {path: 'previousquiz', component:PreviousquizComponent},
  {path: 'notification', component: NotificationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
