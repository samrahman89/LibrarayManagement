
import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { DateAdapter } from '@angular/material';

@Component({
  selector: 'fewaquiz-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = "FEWA Quiz";
  constructor(private translate: TranslateService,
    private adapter: DateAdapter<any>) {
    translate.setDefaultLang('en');
  }

  useLanguage(language: string) {
    this.translate.use(language);
    this.adapter.setLocale(language);
  }
}

