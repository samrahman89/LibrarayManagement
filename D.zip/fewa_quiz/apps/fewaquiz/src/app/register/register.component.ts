import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {
  MatSnackBar,
  MatSnackBarConfig,
} from '@angular/material';
import { API_URL } from '../app.constants';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

export class RegisterDetails {
  constructor (
    public mobile: number,
    public pin: number,
    public repeatPin: number,
    public securityQuestionId: number,
    public securityQuestionAnswer: string,
    public firstName: string,
    public country: string,
    public email: string
  ) {

  }
}

@Component({
  selector: 'fewaquiz-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  postId: any;
  isWait=false;

  constructor(private router: Router, public snackBar: MatSnackBar, private http: HttpClient) { }
  registerDetails : RegisterDetails
    ngOnInit() {
      this.registerDetails=new RegisterDetails(null,null,null,null,null,null,null,null);
    }
    handleRegister() : void {
  if(this.registerDetails.mobile !== null && this.registerDetails.pin !== null &&
    this.registerDetails.repeatPin !== null && this.registerDetails.securityQuestionId !== null &&
    this.registerDetails.securityQuestionAnswer !== null && this.registerDetails.firstName !== null &&
    this.registerDetails.country!==null && this.registerDetails.email!==null){
      if(this.registerDetails.pin !==this.registerDetails.repeatPin)
      {
        const config = new MatSnackBarConfig();
        const message = "PIN Mismatch"
        this.snackBar.open(message, null, {
          duration: 2000,
          panelClass: ['blue-snackbar']
        });
        return;
      }
      else{
        this.isWait=true;
        this.http.post<any>(API_URL+'register/', { user: this.registerDetails }).subscribe(data => {
            this.postId=data.id;
            this.isWait=false;
            this.snackBar.open('Registered Successfully !!!', 'X',
            { duration: 10000, panelClass: ['snack-success'],});
            this.router.navigate(['/'], { replaceUrl: true });
        },
        (err: HttpErrorResponse) => {
          this.isWait=false;
          this.snackBar.open(err.error.message, 'X',
          { duration: 10000, panelClass: ['blue-snackbar'],});
        }
        )
        return;
      }
  }else {
    const config = new MatSnackBarConfig();
    const message = "Please fill all the details to register !!!"
    this.snackBar.open(message, null, {
      duration: 2000,
      panelClass: ['blue-snackbar']
    });
    return;
  }
  }

}
