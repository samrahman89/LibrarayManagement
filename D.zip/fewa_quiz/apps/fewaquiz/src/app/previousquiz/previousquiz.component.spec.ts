import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviousquizComponent } from './previousquiz.component';

describe('PreviousquizComponent', () => {
  let component: PreviousquizComponent;
  let fixture: ComponentFixture<PreviousquizComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreviousquizComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviousquizComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
