import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Option, Question, Quiz, QuizConfig } from '../models/index';
import {
  MatSnackBar,
} from '@angular/material';

import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { API_URL } from '../app.constants';

@Component({
  selector: 'fewaquiz-previousquiz',
  templateUrl: './previousquiz.component.html',
  styleUrls: ['./previousquiz.component.scss']
})
export class PreviousquizComponent implements OnInit {
  quizes: any[];
  quiz: Quiz = new Quiz(null);
  mode = 'quiz';
  quizName: string;
  config: QuizConfig = {
    'allowBack': true,
    'allowReview': false,
    'autoMove': false,  // if true, it will move to next question automatically when answered.
    'duration': 300,  // indicates the time (in secs) in which quiz needs to be completed. 0 means unlimited.
    'pageSize': 1,
    'requiredAll': true,  // indicates if you must answer all the questions before submitting.
    'richText': true,
    'shuffleQuestions': false,
    'shuffleOptions': false,
    'showClock': false,
    'showPager': true,
    'theme': 'none'
  }
  pager = {
    index: 0,
    size: 1,
    count: 1
  };

  isWait=true;

  constructor(private http: HttpClient, public snackBar: MatSnackBar,
    private router: Router) { }

  ngOnInit() {
    this.loadQuiz('FEWA Quiz');
  }

  loadQuiz(quizName: string) {
    const mobile = localStorage.getItem("mobile");
    const pin = localStorage.getItem("pin");
    this.http.get(API_URL+'prevquiz', { headers: {"mobile": mobile,
    "pin":pin} }).subscribe(res => {
      this.isWait=false;
      this.quiz = new Quiz(res);
      if(this.quiz.questions!==undefined)
      {
      this.pager.count = this.quiz.questions.length;
      }
    },
    (err: HttpErrorResponse) => {
      this.isWait=false;
      let message="Server Error";
      if(err.error!==undefined)
      {
        message=err.error.message
      }
      this.snackBar.open(message, 'X',
      { duration: 10000, panelClass: ['blue-snackbar'],});
    }
    );
  }

  get filteredQuestions() {
    return (this.quiz.questions) ?
      this.quiz.questions.slice(this.pager.index, this.pager.index + this.pager.size) : [];
  }

  onSelect(question: Question, option: Option) {
    if (question.questionTypeId === 1) {
      question.options.forEach((x) => { if (x.id !== option.id) x.selected = false; });
    }

    if (this.config.autoMove) {
      this.goTo(this.pager.index + 1);
    }
  }

  goTo(index: number) {
    if (index >= 0 && index < this.pager.count) {
      this.pager.index = index;
      this.mode = 'quiz';
    }
  }

  returnAnswer(question: Question) {
    let name = "";
    question.options.forEach((x) => { if (x.isAnswer){name=x.name }});
    return name;
  };

  isAnswered(question: Question) {
    return question.options.find(x => x.selected) ? true : false;
  };

  isCorrect(question: Question) {
    return question.options.every(x => x.selected === x.isAnswer) ? 'correct' : 'wrong';
  };
  goBack(){
    this.router.navigate(['/home'], { replaceUrl: true });
  }

}
