import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { HomeDetails} from '../models/homeDetails';
import { MatTableDataSource, MatSnackBar } from '@angular/material';
import { Home} from '../models/home';
import { API_URL } from '../app.constants';
import { Router } from '@angular/router';

@Component({
  selector: 'fewaquiz-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  displayedColumns: string[] = ['datum', 'startTime', 'endTime'];
  dataSource = new MatTableDataSource();
  home = new Home("");
  name = localStorage.getItem("name");
  isWait=true;
  isDone=true;

  constructor(private http: HttpClient, public snackBar: MatSnackBar, private router:Router) { }

  ngOnInit() {

    const mobile = localStorage.getItem("mobile");
    const pin = localStorage.getItem("pin");
    this.http.get(API_URL +'home', { headers: {"mobile": mobile,
    "pin":pin} }).subscribe((homeDetails: HomeDetails)=>{
      this.isWait=false;
      this.dataSource.data = homeDetails.details;
      this.home = homeDetails.home;
      if(this.home.endTime===null)
      {
        this.isDone=false;
      }
    },
    (err: HttpErrorResponse) => {
      this.isWait=false;
      let message="Server Error";
      if(err.error!==undefined)
      {
        message=err.error.message
      }
      this.snackBar.open(message, 'X',
      { duration: 10000, panelClass: ['blue-snackbar'],});
    }
    );
  }

  logout(){
    localStorage.clear();
    this.router.navigate(['/'], { replaceUrl: true });
  }

}
